package com.ithuskie.netty2.service;


/**
 * @author: Yakai Zheng（zhengyk@cloud-young.com）
 * @date: Created on 2018/10/23
 * @description:
 * @version: 1.0
 */
public interface TestService {

    void log();
}
