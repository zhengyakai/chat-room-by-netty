package com.ithuskie.netty2.im;

import com.alibaba.fastjson.JSONObject;
import com.ithuskie.netty2.model.MessageObj;
import com.ithuskie.netty2.service.TestService;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@ChannelHandler.Sharable
public class IMHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

	@Autowired
	private TestService testService;
	
	public static ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

	public static Map<Channel,String> map = new ConcurrentHashMap<>(1024);

	@Override
	protected void channelRead0(ChannelHandlerContext ctx,
			TextWebSocketFrame webSocketFrame) throws Exception {
		testService.log();
		Channel incoming = ctx.channel();
        String msg = webSocketFrame.text();
		log.info("收到的消息: "+msg);
		MessageObj messageObj = JSONObject.parseObject(msg, MessageObj.class);
		map.put(incoming, messageObj.getName());
		channels.writeAndFlush(new TextWebSocketFrame(msg));
//		for (Channel channel : channels) {
//			if (channel != incoming){
//			channel.writeAndFlush(new TextWebSocketFrame("[" + messageObj.getName() + "]" + msg));
//			} else {
//			channel.writeAndFlush(new TextWebSocketFrame("[you]" + msg.text() ));
//			}
//		}
	}

	@Override
	public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
		Channel channel = ctx.channel();

		// Broadcast a message to multiple Channels
//		channels.writeAndFlush(new TextWebSocketFrame(channel.remoteAddress() + " 加入"));
		channels.add(channel);
		MessageObj messageObj = new MessageObj();
		System.out.println("Client:"+channel.remoteAddress() +"加入");
	}

	@Override
	public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {  // (3)
		Channel channel = ctx.channel();

		// Broadcast a message to multiple Channels
//		channels.writeAndFlush(new TextWebSocketFrame(channel.remoteAddress() + " 离开"));


		String name = map.get(channel);
		map.remove(channel);
		MessageObj messageObj = new MessageObj();
		messageObj.setTalkWords(name+"离开了聊天室");
		log.info(messageObj.getTalkWords());
		String msg = JSONObject.toJSONString(messageObj);
		channels.writeAndFlush(new TextWebSocketFrame(msg));

		// A closed Channel is automatically removed from ChannelGroup,
		// so there is no need to do "channels.remove(ctx.channel());"
		}
	    
	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception { // (5)
        Channel incoming = ctx.channel();
		System.out.println("Client:"+incoming.remoteAddress()+"在线");
	}
	
	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception { // (6)
        Channel incoming = ctx.channel();
		System.out.println("Client:"+incoming.remoteAddress()+"掉线");
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
			throws Exception {
    	Channel incoming = ctx.channel();
		System.out.println("Client:"+incoming.remoteAddress()+"异常");
        // 当出现异常就关闭连接
        cause.printStackTrace();
        ctx.close();
	}

}