package com.ithuskie.netty2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Netty2Application{

	public static void main(String[] args) {
		SpringApplication.run(Netty2Application.class, args);
	}

}
